<?php

$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'openXBannerTypes', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'openXDeliveryLimitations', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'openXReports', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'openXDeliveryCacheStore', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'openXInvocationTags', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'openXDeliveryLog', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'openXVideoAds', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'reviveMaxMindGeoIP2', 'ext' => 'zip'];
$aDefaultPlugins[] = ['path' => MAX_PATH . '/etc/plugins/', 'name' => 'apVideo', 'ext' => 'zip'];
